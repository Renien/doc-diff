from doc_diff.Diff import Diff
from doc_diff.Diff import _compare_two_files as compare_two_files
from doc_diff.Diff import gen_comp_report
